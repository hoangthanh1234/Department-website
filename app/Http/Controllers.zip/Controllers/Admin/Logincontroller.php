<?php

namespace App\Http\Controllers\Admin;
use Auth;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Requests\LoginRequest;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facedes;
use App\Models\Sinhvien;
use App\Models\Cuusinhvien;
use App\Models\Giangvien;
use App\Models\User;
use App\Models\Phancongtraloi;
use App\Models\Cauhoi;
use Session;


class logincontroller extends Controller{
	
   public function getLogin(){
   		
   		if(Session::has('user_permission')){   			
   			return redirect('set_admin');
   		}
   		else{
   			return view('Admin.Khoa.Layout.Login');
   		}
   }


	public function getLogout(){
		\Session::flush();
		 return redirect('https://www.google.com/accounts/Logout?continue=https://appengine.google.com/_ah/logout?continue=http://ktcn.tvu.edu.vn/set_admin/login#');
	}

	public function getLogout2(){
		\Session::flush();
		return redirect('set_admin/login')->with('thongbao','Bạn không có quyền truy cập tính năng này!!! vui lòng  đăng nhập lại để sử dụng hệ thống');
	}

	

	
}
