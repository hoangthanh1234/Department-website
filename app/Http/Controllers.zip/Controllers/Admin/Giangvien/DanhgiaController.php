<?php

namespace App\Http\Controllers\Admin\Giangvien;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Requests\GiangdayRequest;
use App\Http\Requests\PhieukhacRequest;;
use App\Http\Controllers\Controller;
use App\Models\Thongbaodanhgia;
use App\Models\Phieudanhgia;
use App\Models\Phieugiangday;
use App\Models\Phieukhac;
use App\Models\Tieuchigiangday;
use App\Models\Tieuchi_nckh_baibao;
use App\Models\Tieuchi_nckh_detai;
use App\Models\Tieuchikhac;
use App\Models\CT_baibao;
use App\Models\CT_detai;
use App\Models\Giangvien;
use Carbon\Carbon;
use Session;
use DateTime;

class DanhgiaController extends Controller
{
    public function getGiangday($idtab){

      $Thongbaodanhgia=Thongbaodanhgia::where('hienthi',1)->first();

    // if(count($Thongbaodanhgia) > 0){
    //   $date = date("Y-m-d");
    //   if(strtotime($date)>strtotime($Thongbaodanhgia->ngayketthuc)){
    //       die("Đã quá thời gian đánh giá viên chức");
    //    }
    // }

       $Giangvien = Giangvien::find(Session::get('user_id'));

       if($Giangvien->hangchucdanhnghenghiep == '')
          die('Vui lòng cập nhật thông tin cá nhân về hạng chức danh nghề nghiệp trước khi đánh giá');

       if($Giangvien->bac == 0)
          die('Vui lòng cập nhật thông tin cá nhân về bậc lương hiện tại trước khi đánh giá');

       if($Giangvien->hesoluong == 0)
          die('Vui lòng cập nhật thông tin cá nhân về hệ số lương hiện tại trước khi đánh giá');


    	$Phieudanhgia=Phieudanhgia::where('id_giangvien',Session::get('user_id'))
    								->where('id_thongbao',$Thongbaodanhgia->id)
    								->first();

    	$Tieuchigiangday=Tieuchigiangday::where('hienthi',1)->orderby('stt')->get();

      $Khoagopy = Phieugiangday::where('id_phieu',$Phieudanhgia->id)
                                   ->where('gopykhoa','<>','')
                                   ->orWhere('gopykhoa','<>',null)
                                   ->where('phanhoikhoa','')
                                   ->get();

      $Bomongopy = Phieugiangday::where('id_phieu',$Phieudanhgia->id)
                                   ->where('gopybomon','<>','')
                                   ->orWhere('gopybomon','<>',null)
                                   ->where('phanhoibomon','')
                                   ->get();

    	return view('Admin.Giangvien.Danhgia.Giangday',['tab'=>$idtab,'Phieudanhgia'=>$Phieudanhgia,'Tieuchigiangday'=>$Tieuchigiangday,'Khoagopy'=>$Khoagopy,'Bomongopy'=>$Bomongopy,'Thongbaodanhgia' => $Thongbaodanhgia]);
    }

    public function postGiangday(GiangdayRequest $request){

        $Phieugiangday=Phieugiangday::where('id_phieu',$request->id_phieu)->delete();
        if($request->mycheck!=null){
            foreach ($request->mycheck as $mc){
               $Phieugiangday=new Phieugiangday();
               $Phieugiangday->id_phieu=$request->id_phieu;
               $Phieugiangday->id_tieuchi=$mc;
               $soluong='soluong'.$mc;
               $diemdat='diemdat'.$mc;
               $ghichu = 'ghichu'.$mc;
               $minhchung='minhchunght'.$mc;
               $Phieugiangday->soluong=$request->$soluong;
               $Phieugiangday->diemdat=$request->$diemdat;
               $Phieugiangday->minhchung=$request->$minhchung;
               $Phieugiangday->ghichu = $request->$ghichu;
               $Phieugiangday->giangvienduyet=1;
               $Phieugiangday->save();
            }
        }

        $Phieudanhgia=Phieudanhgia::find($request->id_phieu);
        $Phieudanhgia->diemgiangday=Phieugiangday::where('id_phieu',$request->id_phieu)->sum('diemdat');
        $Phieudanhgia->save();
        return redirect('set_giangvien/danh-gia-vien-chuc/giang-day/1')->with('thongbao','Đã lưu kết đánh giá');
    }

    public function getNghiencuukhoahoc($idtab){

    	$Thongbaodanhgia=Thongbaodanhgia::where('hienthi',1)->first();
      $date = date("Y-m-d");
      if(strtotime($date)>strtotime($Thongbaodanhgia->ngayketthuc)){
          die("Đã quá thời gian đánh giá viên chức");
       }


       $Giangvien = Giangvien::find(Session::get('user_id'));

       if($Giangvien->hangchucdanhnghenghiep == '')
          die('Vui lòng cập nhật thông tin cá nhân về hạng chức danh nghề nghiệp trước khi đánh giá');

       if($Giangvien->bac == 0)
          die('Vui lòng cập nhật thông tin cá nhân về bậc lương hiện tại trước khi đánh giá');

       if($Giangvien->hesoluong == 0)
          die('Vui lòng cập nhật thông tin cá nhân về hệ số lương hiện tại trước khi đánh giá');


    	$Phieudanhgia=Phieudanhgia::where('id_giangvien',Session::get('user_id'))
    								->where('id_thongbao',$Thongbaodanhgia->id)
    								->first();
    	$Tieuchibaibao=Tieuchi_nckh_baibao::where('hienthi',1)->orderby('stt')->get();
      $Tieuchidetai=Tieuchi_nckh_detai::where('hienthi',1)->orderby('stt')->get();



      $Chitietbaibao = CT_baibao::where('id_giangvien',Session::get('user_id'))
                          ->whereHas('baibao',function($query)use($Thongbaodanhgia){
                            $query->whereBetween('nam',[$Thongbaodanhgia->tungay,$Thongbaodanhgia->denngay]);
                          })->get();

      $Chitietdetai = CT_detai::where('id_giangvien',Session::get('user_id'))
                                ->whereHas('detai',function($query)use($Thongbaodanhgia){
                                  $query->whereBetween('ngaynghiemthu',[$Thongbaodanhgia->tungay,$Thongbaodanhgia->denngay]);
                                })->get();


    	return view('Admin.Giangvien.Danhgia.Nghiencuu',['tab'=>$idtab,'Chitietbaibao'=>$Chitietbaibao,'Chitietdetai' => $Chitietdetai,'Tieuchibaibao' => $Tieuchibaibao,'Tieuchidetai' => $Tieuchidetai,'Phieudanhgia' => $Phieudanhgia,'Thongbaodanhgia' => $Thongbaodanhgia]);
    }


  public function getTieuchikhac($idtab){

    	$Thongbaodanhgia=Thongbaodanhgia::where('hienthi',1)->first();
      $date = date("Y-m-d");
      if(strtotime($date)>strtotime($Thongbaodanhgia->ngayketthuc)){
          die("Đã quá thời gian đánh giá viên chức");
       }


       $Giangvien = Giangvien::find(Session::get('user_id'));

       if($Giangvien->hangchucdanhnghenghiep == '')
          die('Vui lòng cập nhật thông tin cá nhân về hạng chức danh nghề nghiệp trước khi đánh giá');

       if($Giangvien->bac == 0)
          die('Vui lòng cập nhật thông tin cá nhân về bậc lương hiện tại trước khi đánh giá');

       if($Giangvien->hesoluong == 0)
          die('Vui lòng cập nhật thông tin cá nhân về hệ số lương hiện tại trước khi đánh giá');

    	$Phieudanhgia=Phieudanhgia::where('id_giangvien',Session::get('user_id'))
    								->where('id_thongbao',$Thongbaodanhgia->id)
    								->first();

    	$Tieuchikhac=Tieuchikhac::where('hienthi',1)->orderby('stt')->get();

      $Khoagopy = Phieukhac::where('id_phieu',$Phieudanhgia->id)
                                   ->where('gopykhoa','<>',null)
                                   ->where('phanhoikhoa',null)
                                   ->get();

      $Bomongopy = Phieukhac::where('id_phieu',$Phieudanhgia->id)
                                   ->where('gopybomon','<>',null)
                                   ->where('phanhoibomon',null)
                                   ->get();

    	return view('Admin.Giangvien.Danhgia.Tieuchikhac',['tab'=>$idtab,'Phieudanhgia'=>$Phieudanhgia,'Tieuchikhac'=>$Tieuchikhac,'Khoagopy'=>$Khoagopy,'Bomongopy'=>$Bomongopy,'Thongbaodanhgia' => $Thongbaodanhgia]);
  }


    public function postTieuchikhac(PhieukhacRequest $request){

        $Phieukhac=Phieukhac::where('id_phieu',$request->id_phieu)->delete();
        if($request->mycheck!=null){
            foreach ($request->mycheck as $mc){
               $Phieukhac=new Phieukhac();
               $Phieukhac->id_phieu=$request->id_phieu;
               $Phieukhac->id_tieuchi=$mc;
               $soluong='soluong'.$mc;
               $diemdat='diemdat'.$mc;
               $minhchung='minhchunght'.$mc;
               $Phieukhac->soluong=$request->$soluong;
               $Phieukhac->diemdat=$request->$diemdat;
               $Phieukhac->minhchung=$request->$minhchung;
               $Phieukhac->giangvienduyet=1;
               $Phieukhac->save();
            }
        }

        $Phieudanhgia=Phieudanhgia::find($request->id_phieu);
        $Phieudanhgia->diemkhac=Phieukhac::where('id_phieu',$request->id_phieu)->sum('diemdat');
        $Phieudanhgia->save();
        return redirect('set_giangvien/danh-gia-vien-chuc/tieu-chi-khac/3')->with('thongbao','Đã lưu kết đánh giá');
    }

     public function getquydinh($idtab){
      return view('Admin.Giangvien.Danhgia.Xemthongbao',['tab'=>$idtab]);
  }

  public function getquydinhkhac($idtab){
   return view('Admin.Giangvien.Danhgia.Xemthongbaokhac',['tab'=>$idtab]);
}



    public function test(){
    	// $Tieuchi=Tieuchi::where('id_tieuchuan',2)->get();
    	// foreach ($Tieuchi as $tc) {
	    // 	$Tieuchi_nckh_detai =new Tieuchi_nckh_detai();
	    // 	$max=Tieuchi_nckh_detai::max('id');
	    // 	$Tieuchi_nckh_detai->stt=$max+1;
	    // 	$Tieuchi_nckh_detai->ten=$tc->ten;
	    // 	$Tieuchi_nckh_detai->diem=$tc->diem;
	    // 	$Tieuchi_nckh_detai->donvitinh=$tc->donvitinh;
	    //     $Tieuchi_nckh_detai->loaiminhchung=$tc->loaiminhchung;
	    //     $Tieuchi_nckh_detai->id_capdetai=100;
	    //     $Tieuchi_nckh_detai->id_loaitacgia=100;
	    // 	$Tieuchi_nckh_detai->save();
    	// }
    	$Tieuchi_nckh_baibao=Tieuchi_nckh_baibao::where('ten','like','%đề tài%')->delete();

    }
}
