<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\Phancongtraloi;
use App\Models\Giangvien;

class EmailController extends Controller{

    

}
